import axios from 'axios'

const API_BASE = 'https://nievexsviz.my.id'
const API_KEY = 'nvxc'

const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'x-api-key': API_KEY
  }
})

export const cdnService = {
  async uploadFile(file) {
    const formData = new FormData()
    formData.append('file', file)
    
    const response = await api.post('/api/v1/cdn', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    return response.data
  }
}

export const shortenerService = {
  async createShortUrl(url, customId = null) {
    const data = { url }
    if (customId) {
      data.customId = customId
    }
    
    const response = await api.post('/api/v1/short', data)
    return response.data
  }
}

export const healthService = {
  async checkHealth() {
    const response = await axios.get(`${API_BASE}/health`)
    return response.data
  }
}